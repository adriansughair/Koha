module.exports = {
    xlarge: 35,
    large: 25,
    medium: 15,
    small: 10,
    xsmall: 5,

    fontLarge: 26,
    fontMedium: 20
};